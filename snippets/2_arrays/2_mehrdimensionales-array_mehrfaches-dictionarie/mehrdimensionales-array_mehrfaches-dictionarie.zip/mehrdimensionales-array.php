<?php

$personen = [

[
    "Name" => "Klara",
    "Alter" => 32,
    "Geschlecht" => "Weiblich"
],
    
[
    "Name"=>"Peter",
    "Alter"=>25,
    "Geschlecht"=>"Männlich"
],
        
[
    "Name" => "Hans-Franz",
    "Alter" => 86,
    "Geschlecht" => "Männlich"
]

];

print_r($personen);

?>