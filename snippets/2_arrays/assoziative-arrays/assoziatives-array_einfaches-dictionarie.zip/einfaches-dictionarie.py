meine_person = {
    "Vorname": "Sven",
    "Zweitname": "Oliver",
    "Nachname": "Berger",
    "Augenfarbe": "Blau",
    "Beruf": "Umschulung zum Fachinformatiker für Anwendungsentwicklung"
}

print(f"Mein Name ist {meine_person['Vorname']} {meine_person['Zweitname']} {meine_person['Nachname']} und meine Augenfarbe ist {meine_person['Augenfarbe'].lower()}.")